//{{NO_DEPENDENCIES}}
// fichier Include Microsoft Visual C++.
// Utilis� par EmbeddedLists.rc
//
#define IDC_NEXT                        1
#define IDD_LISTVIEW                    101
#define IDD_TREEVIEW                    102
#define IDB_BITMAP                      110
#define IDC_GROUPBOX                    1210
#define IDC_HEADINGTEXT                 1211
#define IDC_LIST                        1212
#define IDC_CHECK1                      1221
#define IDC_CHECKALL                    1221

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1222
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
