//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by EmbeddedLists.rc
//
#define IDD_LISTVIEW                    101
#define IDD_TREEVIEW                    102
#define IDC_NEXT                        1
#define IDC_GROUPBOX                    1210
#define IDC_HEADINGTEXT                 1211
#define IDC_LIST                        1212
#define IDB_BITMAP                      110

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1221
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
