javac -d . -cp .:JNative.jar ../../../Source/MediaInfoDLL/MediaInfoDLL.java ../../../Source/Example/HowToUse_Dll.java
