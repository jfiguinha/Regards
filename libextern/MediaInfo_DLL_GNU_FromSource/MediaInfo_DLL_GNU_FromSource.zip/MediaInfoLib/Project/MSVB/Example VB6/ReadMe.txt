These files are Visual Basic 6 example.
But because I work on Visual Basic 7 now, I will not maintain them.

So don't be surprise if it does'nt work without any little modifications...