java -cp .:jna.jar HowToUse_Dll $1
