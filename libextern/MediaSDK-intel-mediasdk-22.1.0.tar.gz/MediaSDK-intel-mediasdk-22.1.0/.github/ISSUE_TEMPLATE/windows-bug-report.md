---
name: Windows Bug report
about: Create a report to help us improve
title: ''
labels: bug, win
assignees: ''

---

## System information
- CPU information (link to ark.intel.com):
- GPU information (link to ark.intel.com):
- Driver version:

## Issue behavior
### Describe the current behavior

### Describe the expected behavior
