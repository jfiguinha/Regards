#ifndef B64_CONFIG_H
#define B64_CONFIG_H

#define LIBB64

#endif
