.. _parallel_for_toctree:

.. toctree::
   :maxdepth: 4

   ../tbb_userguide/Lambda_Expressions
   ../tbb_userguide/Automatic_Chunking
   ../tbb_userguide/Controlling_Chunking_os
   ../tbb_userguide/Bandwidth_and_Cache_Affinity_os
   ../tbb_userguide/Partitioner_Summary