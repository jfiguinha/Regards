# vcpkg-qmake

This port contains qmake functions for dealing with a QMake buildsystem.

In the common case, `vcpkg_qmake_configure()` (with appropriate arguments)
followed by `vcpkg_install_qmake()` will be enough to build and install a port.

