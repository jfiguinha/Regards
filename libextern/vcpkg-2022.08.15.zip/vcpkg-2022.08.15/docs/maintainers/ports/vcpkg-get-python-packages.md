# vcpkg-get-python-packages

**Experimental: will change or be removed at any time**

`vcpkg-get-python-packages` provides `x_vcpkg_get_python_packages()`, a function which simplifies getting
python packages. 
