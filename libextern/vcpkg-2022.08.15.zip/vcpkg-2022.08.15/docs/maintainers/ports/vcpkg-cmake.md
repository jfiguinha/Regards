# vcpkg-cmake

This port contains portfile helper functions for dealing with a CMake buildsystem.

- [`vcpkg_cmake_configure()`](../vcpkg_cmake_configure.md)
- [`vcpkg_cmake_install()`](vcpkg-cmake/vcpkg_cmake_install.md)
- [`vcpkg_cmake_build()`](vcpkg-cmake/vcpkg_cmake_build.md)
