/////////////////////////////////////////////////////////////////////////////
// Name:        class_miscwnd.h
// Purpose:     Miscellaneous Windows classes group docs
// Author:      wxWidgets team
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_miscwnd Miscellaneous Windows
@ingroup group_class

The following are a variety of classes that are derived from wxWindow.

*/

