//---------------------------------------------------------------------------
// Help.cpp : Help pane text
//---------------------------------------------------------------------------
#include "Help.h"

// NB : If more text is to go in here don't forget to enlarge min/max
extern char  *_szHelp = {
"\nA MNG developers tool to display the chunk data of MNG/JNG/PNG files."\
"\n"
"\nMngDump - Version 1.0 - September 2000"\
"\n"\
"\n NOTE - This program comes with NO warranties whatsoever."\
"\n"\
"\nInstruction for use ... press the folder button and load a file !"\
"\n"\
"\nThe following chunks are (currently) unsupported :"\
"\nIJNG, IPNG, JSEP, MaGN, MAGN, oFFs, pCAL, sCAL"\
"\n"\
"\nThe program will be periodically updated, inline with libmng's growth."\
"\nPlease report any bugs, suggestions, etc to the maintainer."
};
//---------------------------------------------------------------------------

