//---------------------------------------------------------------------------
// About.cpp : About pane text
//---------------------------------------------------------------------------
#include "About.h"

// NB : If more text is to go in here don't forget to enlarge min/max
extern char  *_szAbout = {
"\nCopyright (c) 2000 Andy Protano (a.a.protano@care4free.net)"\
"\n                   Gerard Juyn (gerard@libmng.com)"\
"\n"\
"\nLibmng website - www.libmng.com"
"\nMNG Homepage - www.libpng.org/pub/mng"
"\nPNG Homepage - www.libpng.org/pub/png"
"\n"
"\nThis program is based upon the orignal \'MngTree\' by Gerard Juyn"\
"\nAuthor & current maintainer : Andy Protano (a.a.protano@care4free.net)"\
"\n"\
"\nThis software is based on libmng which in its turn is based on software by :"\
"\n"\
"\nIndependant JPEG Group - http://www.ijg.org"\
"\nLcms (little CMS) library by Marti Maria Saguar - http://www.lcms.colorid.de"\
"\nZlib - http://www.info-zip.org/pub/infozip/zlib"\
};
//---------------------------------------------------------------------------

