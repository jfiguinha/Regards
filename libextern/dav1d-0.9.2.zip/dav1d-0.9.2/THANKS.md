# The dav1d project and VideoLAN association would like to thank

## AOM
The Alliance for Open Media (AOM) for funding this project.

## Companies
* Two Orioles LLC, for important coding effort
* VideoLabs SAS

## Projects
* VideoLAN
* FFmpeg
* libplacebo

## Individual

And all the dav1d Authors (git shortlog -sn), including:

Martin Storsjö, Janne Grunau, Henrik Gramner, Ronald S. Bultje, James Almer,
Marvin Scholz, Luc Trudeau, Victorien Le Couviour--Tuffet, Jean-Baptiste Kempf,
Hugo Beauzée-Luyssen, Matthias Dressel, Konstantin Pavlov, David Michael Barr,
Steve Lhomme, Niklas Haas, B Krishnan Iyer, Francois Cartegnie, Liwei Wang,
Nathan E. Egge, Derek Buitenhuis, Michael Bradshaw, Raphaël Zumer,
Xuefeng Jiang, Luca Barbato, Jan Beich, Wan-Teh Chang, Justin Bull, Boyuan Xiao,
Dale Curtis, Kyle Siefring, Raphael Zumer, Rupert Swarbrick, Thierry Foucu,
Thomas Daede, Colin Lee, Emmanuel Gil Peyrot, Lynne, Michail Alvanos,
Nico Weber, SmilingWolf, Tristan Laurent, Vittorio Giovara, Anisse Astier,
Dmitriy Sychov, Ewout ter Hoeven, Fred Barbier, Jean-Yves Avenard,
Mark Shuttleworth, Matthieu Bouron, Nicolas Frattaroli, Pablo Stebler,
Rostislav Pehlivanov, Shiz, Steinar Midtskogen, Sylvestre Ledru, Timo Gurr,
Tristan Matthews, Xavier Claessens, Xu Guangxin, kossh1 and skal.
