patchelf --force-rpath --set-rpath '$ORIGIN' *.so.* 

