# -*- coding: utf-8 -*-

import system_tests
system_tests.BT.verbose_version(True)
