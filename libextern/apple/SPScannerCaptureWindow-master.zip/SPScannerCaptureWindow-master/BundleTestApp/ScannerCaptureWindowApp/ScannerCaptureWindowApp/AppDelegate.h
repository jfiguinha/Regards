
#import <Cocoa/Cocoa.h>
#import "SPWindowBundle.h"

@interface AppDelegate : NSObject <NSApplicationDelegate, WindowBundleDelegate>


- (IBAction)openScanSheet:(id)sender;

@end

