
#import <Cocoa/Cocoa.h>

@class CaptureWindow;

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property CaptureWindow *window;

@end
