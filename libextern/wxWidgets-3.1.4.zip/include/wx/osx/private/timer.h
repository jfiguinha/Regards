#if 1 // revert to wxOSX_USE_COCOA_OR_IPHONE in case of problems
    #include "wx/osx/core/private/timer.h"
#endif
